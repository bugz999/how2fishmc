package gg.melty.htf;

import java.io.IOException;
import java.nio.file.*;
import java.util.*;
import java.util.regex.*;

/** Finds the player's own How to Fish install through Steam's library folders. */
public final class HtfLocator {
  private static final String DIR = "How to Fish";
  private HtfLocator() {}

  public static Optional<Path> find() {
    List<Path> steamRoots = new ArrayList<>();
    String pf = System.getenv("ProgramFiles(x86)");
    if (pf != null) steamRoots.add(Paths.get(pf, "Steam"));
    steamRoots.add(Paths.get(System.getProperty("user.home"), ".local/share/Steam"));
    steamRoots.add(Paths.get(System.getProperty("user.home"), "Library/Application Support/Steam"));

    Set<Path> libs = new LinkedHashSet<>();
    Pattern p = Pattern.compile("\"path\"\\s+\"([^\"]+)\"");
    for (Path root : steamRoots) {
      libs.add(root);
      Path vdf = root.resolve("steamapps/libraryfolders.vdf");
      if (!Files.isRegularFile(vdf)) continue;
      try {
        Matcher m = p.matcher(Files.readString(vdf));
        while (m.find()) libs.add(Paths.get(m.group(1).replace("\\\\", "\\")));
      } catch (IOException ignored) {}
    }
    for (Path lib : libs) {
      Path g = lib.resolve("steamapps/common").resolve(DIR);
      if (Files.isDirectory(g)) return Optional.of(g);
    }
    return Optional.empty();
  }
}
