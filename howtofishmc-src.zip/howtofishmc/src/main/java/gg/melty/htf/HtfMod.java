package gg.melty.htf;

import com.mojang.brigadier.Command;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.loot.v3.LootTableEvents;
import net.minecraft.item.Item;
import net.minecraft.loot.LootPool;
import net.minecraft.loot.entry.ItemEntry;
import net.minecraft.registry.*;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.world.Heightmap;
import net.minecraft.world.World;
import java.nio.file.Path;
import java.util.Optional;
import org.slf4j.*;

public class HtfMod implements ModInitializer {
  public static final String ID = "howtofishmc";
  public static final Logger LOG = LoggerFactory.getLogger(ID);
  public static final RegistryKey<World> DEPTHS = RegistryKey.of(RegistryKeys.WORLD, Identifier.of(ID, "depths"));
  public static Item CATCH;
  public static Optional<Path> htfHome = Optional.empty();
  public static CreatureSheet sheet;

  @Override public void onInitialize() {
    CATCH = Registry.register(Registries.ITEM, Identifier.of(ID, "htf_catch"), new Item(new Item.Settings().maxCount(16)));

    htfHome = HtfLocator.find();
    sheet = CreatureSheet.load(htfHome.orElse(null));
    LOG.info("How to Fish install: {}", htfHome.map(Path::toString).orElse("NOT FOUND"));
    sheet.problems.forEach(p -> LOG.warn("preflight: {}", p));

    // Catching: rod fishing can also yield a kept creature item.
    LootTableEvents.MODIFY.register((key, table, source) -> {
      if (key.getValue().equals(Identifier.ofVanilla("gameplay/fishing/fish")))
        table.pool(LootPool.builder().with(ItemEntry.builder(CATCH).weight(30)));
    });

    // Travel (portal block still to do): /htf
    CommandRegistrationCallback.EVENT.register((d, reg, env) -> d.register(
      CommandManager.literal("htf").executes(ctx -> {
        ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
        if (htfHome.isEmpty())
          p.sendMessage(Text.literal("How to Fish isn't installed on this PC, so its creatures can't load. The dimension still works."));
        ServerWorld w = ctx.getSource().getServer().getWorld(DEPTHS);
        if (w == null) { p.sendMessage(Text.literal("Dimension not loaded.")); return 0; }
        int y = w.getTopY(Heightmap.Type.MOTION_BLOCKING, 0, 0) + 1;
        p.teleport(w, 0.5, y, 0.5, p.getYaw(), p.getPitch());
        return Command.SINGLE_SUCCESS;
      })));
  }
}
