package gg.melty.htf;

import com.google.gson.*;
import java.io.*;
import java.nio.file.*;
import java.util.*;

/** Loads the creatures sheet and runs the preflight: every cell filled, every source resolves. */
public final class CreatureSheet {
  public record Row(String id, String displayName, String htfSource, String kind,
                    String minecraftBase, String rarity, boolean keptAsItem) {}

  public final List<Row> rows = new ArrayList<>();
  public final List<String> problems = new ArrayList<>();

  public static CreatureSheet load(Path htfHome) {
    CreatureSheet s = new CreatureSheet();
    try (InputStream in = CreatureSheet.class.getResourceAsStream("/data/howtofishmc/sheets/creatures.json")) {
      JsonObject o = JsonParser.parseReader(new InputStreamReader(in)).getAsJsonObject();
      for (JsonElement e : o.getAsJsonArray("rows")) {
        JsonObject r = e.getAsJsonObject();
        String id = str(r, "id");
        for (String c : List.of("id","displayName","htfSource","kind","minecraftBase","rarity"))
          if (str(r, c) == null) s.problems.add(id + ": missing " + c);
        String src = str(r, "htfSource");
        if (src != null && (htfHome == null || !Files.exists(htfHome.resolve(src))))
          s.problems.add(id + ": htfSource not found: " + src);
        s.rows.add(new Row(id, str(r,"displayName"), src, str(r,"kind"), str(r,"minecraftBase"),
            str(r,"rarity"), r.has("keptAsItem") && r.get("keptAsItem").getAsBoolean()));
      }
    } catch (Exception ex) { s.problems.add("sheet unreadable: " + ex); }
    return s;
  }
  private static String str(JsonObject o, String k) {
    return o.has(k) && !o.get(k).isJsonNull() && !o.get(k).getAsString().isBlank() ? o.get(k).getAsString() : null;
  }
}
